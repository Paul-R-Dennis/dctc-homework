package divide;

public class Divide{
    public static void main(String args[]){
        double x = Double.parseDouble((args[0]));
        double y = Double.parseDouble((args[1]));

        double result = divide(x, y);

        System.out.println(result);
    }
    public static double divide(double a, double b){
        double result = a / b;
        return result;
    }
}