import add.Add;
import divide.Divide;
import multiply.Multiply;
import subtract.Subtract;

public class Math {
    public static void main(String[] args) {
        String x = args[0];
        double y = Double.parseDouble((args[1]));
        double z = Double.parseDouble((args[2]));

        if (x.equals("add")) {
            double result = Add.add(y, z);
            System.out.println(result);
        }

        else if (x.equals("divide")) {
            double result = Divide.divide(y, z);
            System.out.println(result);
        }

        else if (x.equals("multiply")) {
            double result = Multiply.multiply(y, z);
            System.out.println(result);
        }

        else if (x.equals("subtract")) {
            double result = Subtract.subtract(y, z);
            System.out.println(result);
        }
    }
}