package add;

public class Add{
    public static void main(String args[]){
        double x = Double.parseDouble((args[0]));
        double y = Double.parseDouble((args[1]));

        double result = add(x, y);

        System.out.println(result);
    }
    public static double add(double a, double b){
        double result = a + b;
        return result;
    }
}