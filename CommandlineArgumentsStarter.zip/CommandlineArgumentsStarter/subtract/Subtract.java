package subtract;

public class Subtract{
    public static void main(String args[]){
        double x = Double.parseDouble((args[0]));
        double y = Double.parseDouble((args[1]));

        double result = subtract(x, y);

        System.out.println(result);
    }
    public static double subtract(double a, double b){
        double result = a - b;
        return result;
    }
}