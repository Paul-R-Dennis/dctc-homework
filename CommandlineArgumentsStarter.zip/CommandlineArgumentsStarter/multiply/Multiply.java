package multiply;

public class Multiply{
    public static void main(String args[]){
        double x = Double.parseDouble((args[0]));
        double y = Double.parseDouble((args[1]));

        double result = multiply(x, y);

        System.out.println(result);
    }
    public static double multiply(double a, double b){
        double result = a * b;
        return result;
    }
}