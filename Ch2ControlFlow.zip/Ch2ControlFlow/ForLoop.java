public class ForLoop {
    public static void main(String[] args) {
        for (int x = 0; x < 5; x++) {
            System.out.println("Hello For Loop");
        }
    }
}
