import java.util.Scanner;

public class HelloUserWhile {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int y = 0;

        System.out.print("Enter your name: ");
        String x = scanner.nextLine();

        while (y < 5) {
            System.out.println("Hello " + x + "!");
            y++;
        }
        
        scanner.close();
    }
}
