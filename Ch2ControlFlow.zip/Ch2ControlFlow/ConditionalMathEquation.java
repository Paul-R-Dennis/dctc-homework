import java.util.Scanner;

public class ConditionalMathEquation {
    public static void main(String[] args){
        //opens scanner
        Scanner scanner = new Scanner(System.in);
        double result;

        //inputs
        System.out.print("Enter 4 numbers:");
        double first = scanner.nextDouble();
        double second = scanner.nextDouble();
        double third = scanner.nextDouble();
        double fourth = scanner.nextDouble();
        

        if (third == 0){
            if (second >= 0){
                result = (first + second) * fourth;
                System.out.println("(" + first + "+" + second + ") * " + fourth + "=" + result);
            }
            else if (second < 0) {
                result = (first - second) * fourth;
                System.out.println("(" + first + "-" + second + ") * " + fourth + " = " + result);
            }
        }
        else if (third != 0) {
            result = (first / third) * second + (fourth/third);
            System.out.println("(" + first + "/" + third + ") * " + second + " + (" + fourth + "/" + third + ") = " + result);
        }

        //closes the scanner
        scanner.close();
    }
}
