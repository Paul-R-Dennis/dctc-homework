import java.util.Scanner;

public class OrTruthTable {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a boolean:");
        boolean x = scanner.nextBoolean();

        System.out.println(x + " or true==" + (x||true));
        System.out.println(x + " or false==" + (x||false));
        System.out.println(!x + " or true==" + (!x||true));
        System.out.println(!x + " or false==" + (!x||false));

        scanner.close();
    }
}
