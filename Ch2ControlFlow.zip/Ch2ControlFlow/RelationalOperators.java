//Ch 2 Assignment: Paul Dennis
//Due 9/18/22
import java.util.Scanner;

public class RelationalOperators {
    public static void main(String[] args) {
        //opens scanner for input
        Scanner scanner = new Scanner(System.in);

        //asks/takes first user input
        System.out.println("Enter a number:");
        int x = scanner.nextInt();

        //asks/takes second user input
        System.out.println("Enter another number:");
        int y = scanner.nextInt();

        //opens boolean variables
        boolean lessThan = true;
        boolean lessThanOrEqual = true;
        boolean greaterThan = true;
        boolean greaterThanOrEqual = true;
        boolean equals = true;
        boolean doesNotEqual = true;

        //checks all operators
        lessThan = (x<y);
        System.out.println(x + "<" + y + "?" + lessThan);

        lessThanOrEqual = (x<=y);
        System.out.println(x + "<=" + y + "?" + lessThanOrEqual);

        greaterThan = (x>y);
        System.out.println(x + ">" + y + "?" + greaterThan);

        greaterThanOrEqual = (x>=y);
        System.out.println(x + ">=" + y + "?" + greaterThanOrEqual);

        equals = (x==y);
        System.out.println(x + "=" + y + "?" + equals);

        doesNotEqual = (x!=y);
        System.out.println(x + "!=" + y + "?" + doesNotEqual);

        //closes scanner
        scanner.close();
    }
}