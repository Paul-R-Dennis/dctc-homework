import java.util.Scanner;

public class CompositLogicalOperators {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter an integer number:");
        int x = scanner.nextInt();

        if ((x %2 != 0 && x > 100) || (x %2 == 0 && x < 100)){
            System.out.println("(the number is odd and greater than 100) or (the number is even and less than 100)");
        }

        if (x != 42) {
            System.out.println("you do not have the answer");
        }

        if ((x > 100) || (x < 50 && x < 15)){
            System.out.println("(the number is greater than 100) or (less than 50 and not even and greater than 15)");
        }

        scanner.close();
    }
}