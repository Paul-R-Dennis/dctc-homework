import java.util.Scanner;

public class ConditionalExpression {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("The Vikings are the best NFL team: true or false");
        boolean x = scanner.nextBoolean();

        if (x) {
            System.out.println("You are correct");
        } else {
            System.out.println("You are wrong");
        }

        scanner.close();
    }
}