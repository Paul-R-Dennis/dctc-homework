import java.util.Scanner;

public class HelloUserDoWhile {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int y = 0;

        System.out.print("Enter your name: ");
        String x = scanner.nextLine();

        do {
            System.out.println("Hello " + x + "!");
            y++;
        }
        while (y < 5);
        
        scanner.close();
    }
}
