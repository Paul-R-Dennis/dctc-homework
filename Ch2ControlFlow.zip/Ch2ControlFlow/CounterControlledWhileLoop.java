public class CounterControlledWhileLoop {
    public static void main(String[] args){
        int x = 0;

        while (x < 5) {
            System.out.println("Hello Counter Controlled Loop");
            x++;
        }
    }
}
