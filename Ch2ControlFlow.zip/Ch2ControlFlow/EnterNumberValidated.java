import java.util.Scanner;

public class EnterNumberValidated {
    public static void main(String[] main) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a number between 10 and 20: ");
        int x = scanner.nextInt();

        while (x < 10 || x > 20) {
            System.out.print("Invalid input, try again: ");
            x = scanner.nextInt();
        }

        System.out.println("You entered " + x);

        scanner.close();
    }
}
