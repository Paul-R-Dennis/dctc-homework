import java.util.Scanner;

public class SwitchStatement {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter an integer number:");
        int x = scanner.nextInt();

        switch (x) {
            case 1: 
                System.out.println("You entered 1");
                break;
            case 2:
                System.out.println("You entered 2");
                break;
            case 3:
                System.out.println("You entered 3");
                break;
            case 4:
                System.out.println("You entered4");
                break;
            case 5:
                System.out.println("You entered 5");
                break;
            default:
                System.out.println("You did not enter 1-5");

        }

        scanner.close();
    }
}