import java.util.Scanner;

public class ExclusiveOrTruthTable {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a boolean:");
        boolean x = scanner.nextBoolean();

        System.out.println(x + " xor true==" + (x ^ true));
        System.out.println(x + " xor false==" + (x ^ false));
        System.out.println(!x + " xor true==" + (!x ^ true));
        System.out.println(!x + " xor false==" + (!x ^ false));

        scanner.close();
    }
}