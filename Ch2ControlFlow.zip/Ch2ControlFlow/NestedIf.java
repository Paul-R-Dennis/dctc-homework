//Ch 2 Assignment: Paul Dennis
//Due 9/18/22
import java.util.Scanner;

public class NestedIf {
    public static void main(String[] args) {
        //opens scanner for input
        Scanner scanner = new Scanner(System.in);

        //asks user for input
        System.out.println("Enter a integer number:");
        int x = scanner.nextInt();

        //checks if number is > 10
        if (x>10) {
            System.out.println("The number you have entered is greater than 10");
        } else {
            //checks if number is < 5
            if (x<5) {
                System.out.println("The number you have entered is less than 5");
            } else {
                System.out.println("The number you have entered is between 5 and 10");
            }
        }

        //prints the number entered
        System.out.println("The number you entered is:" + x);

        //closes scanner
        scanner.close();
    }
}