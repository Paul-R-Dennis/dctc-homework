import java.util.Scanner;

public class OddNumber {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter an integer number:");
        int x = scanner.nextInt();

        System.out.println("You entered " + x);

        if (x %2 != 0){
            System.out.println(x + " is odd");
        }

        scanner.close();
    }
}
