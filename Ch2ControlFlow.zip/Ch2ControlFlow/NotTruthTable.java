import java.util.Scanner;

public class NotTruthTable {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a boolean:");
        boolean x = scanner.nextBoolean();

        System.out.println("You entered " + x + ", !" + x + "==" + !x);

        scanner.close();
    }
}
