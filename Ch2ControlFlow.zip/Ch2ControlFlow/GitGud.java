import java.util.Scanner;

public class GitGud {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter an integer number:");
        int x = scanner.nextInt();

        if ((x % 3 == 0) && (x %5 != 0)) {
            System.out.print("Git");
        }

        else if ((x %5 == 0) && (x %3 != 0)) {
            System.out.print("Gud");
        }

        else if ((x %5 == 0) && (x %3 == 0)) {
            System.out.print("GitGud");
        }

        else {
            System.out.println(x);
        }
        scanner.close();
    }
}