import java.util.Scanner;

public class ifStatements {
    public static void main(String[] args){
        //opens scanner
        Scanner scanner = new Scanner(System.in);

        //asks user for input
        System.out.println("Enter a integer number:");
        int x = scanner.nextInt();

        //checks if number is > 10
        if (x>10) {
            System.out.println("The number you have entered is greater than 10");
        }

        //checks if number is < 5
        if (x<5) {
            System.out.println("The number you have entered is less than 5");
        }

        //prints the number entered
        System.out.println("The number you entered is:" + x);

        //closes scanner
        scanner.close();
    }
}
