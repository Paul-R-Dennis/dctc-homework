import java.util.Scanner;

public class AndTruthTable {
    public static void main(String[] args)    {
        Scanner scanner = new Scanner(System.in);

         System.out.print("Enter a boolean:");
         boolean x = scanner.nextBoolean();

         System.out.println(x + " and true ==" + (x&&true));
         System.out.println(x + " and false==" + (x&&false));
         System.out.println(!x + " and true==" + (x&&true));
         System.out.println(!x + " and false==" + (x&&false));

         scanner.close();
    }
}
