public class DoWhileLoop {
    public static void main(String[] args){
        int x = 0;

        do {
            System.out.println("Hello Do While Loop");
            x++;
        } while (x < 5);
    }
    
}
