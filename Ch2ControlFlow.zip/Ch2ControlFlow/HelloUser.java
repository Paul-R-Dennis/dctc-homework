import java.util.Scanner;

public class HelloUser {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter your name: ");
        String x = scanner.nextLine();

        System.out.println("Hello " + x + "!");

        scanner.close();
    }
}
