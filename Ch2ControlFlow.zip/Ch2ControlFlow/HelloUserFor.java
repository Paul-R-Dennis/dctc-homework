import java.util.Scanner;

public class HelloUserFor {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter your name: ");
        String x = scanner.nextLine();

        for (int y = 0; y < 5; y++){
            System.out.println("Hello " + x + "!");
       }
        
        scanner.close();
    }
}
