from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

fruits = [{"id":1,"name":"Apple","description":"Red Delicious"}]
last_index = 0
#Goal: CreateReadUpdateDelete from fruits!

#Read all!
@app.get('/fruits')
def all_fruits():
    return render_template('/fruits/all.html',fruits=fruits)

@app.get('/fruits/add')
def fruit_form():
    return render_template('/fruits/add_form.html')
#Create!
@app.post('/fruits')
def create_fruit():
    global last_index
    new_id = last_index + 1
    last_index = new_id
    new_name = request.form['fruitName']
    new_description = request.form['fruitDescription']
    new_fruit = {'name':new_name,'id':new_id,'description':new_description}
    fruits.append(new_fruit)
    return redirect(url_for('all_fruits'))

def find_fruit(id):
    found_fruit = None
    for fruit in fruits:
        if fruit['id'] == id:
            found_fruit = fruit 
            break
    return found_fruit

#Read single fruit
@app.get('/fruits/<int:id>')
def read_fruit(id):
    fruit = find_fruit(id)
    return render_template('/fruits/show.html',fruit=fruit)

@app.post('/fruits/<int:id>')
def form_to_other_http_methods(id):
    if request.form['_method'] == 'DELETE':
        return delete_fruit(id)
    if request.form['_method'] == 'PUT':
        return update_fruit(id)
    return "UKNOWN METHOD " + request.form['_method']

#DELETE!
@app.delete('/fruits/<int:id>')
def delete_fruit(id):
    fruit = find_fruit(id)
    fruits.remove(fruit)
    return redirect(url_for('all_fruits'))

@app.get('/fruits/<int:id>/update')
def update_form(id):
    fruit = find_fruit(id)
    return render_template('/fruits/update.html',fruit=fruit)

@app.put('/fruits/<int:id>')
def update_fruit(id):
    fruit = find_fruit(id)
    fruit['name'] = request.form['fruitName']
    fruit['description'] = request.form['fruitDescription']
    return redirect(url_for('read_fruit',id=id))