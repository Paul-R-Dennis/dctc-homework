from random import randrange
from flask import Flask,request, render_template

app = Flask(__name__)

@app.get('/')
def home():
    return render_template("main.html")
def ai():
    choices = ['rock','paper','scicors']
    ai_choice = choices[randrange(0,len(choices))]
    return ai_choice

def winner(human,ai):
    if human == ai:
        return "You both selected " + human + ". It's a tie!"
    elif human == "rock":
        if ai == "scicors":
            return "Rock beats scicors, you win!"
        else:
            return "Paper beats rock, you lose."
    elif human == "paper":
        if ai == "rock":
            return "Paper beats rock, you win!"
        else:
            return "Scicors beats paper, you lose."
    elif human == "scicors":
        if ai == "paper":
            return "Scicors beats paper, you win!"
        else:
            return "Rock beats scicors, you lose."
@app.get('/game')
def game():
    human = request.args['choice']
    ai_pick = ai()
    return render_template("game.html",human=human,ai_pick=ai_pick,winner=winner(human,ai_pick))

