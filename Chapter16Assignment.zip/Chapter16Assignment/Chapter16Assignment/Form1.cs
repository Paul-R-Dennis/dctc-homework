﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chapter16Assignment
{
    public partial class Form1 : Form
    {
        //Pig Latin ending, constant across all words
        const string pigLatinEnding = "ay";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        //function to translate the word on click
        private void translateButton_Click(object sender, EventArgs e)
        {
            //initializing needed variables for translations
            string translation = "";
            string inputText = inputTextBox.Text;

            //validating input
            if (validate(inputText) == true)
            {
                //adding the input sentence to a text box
                originalSentences.Text += inputText + Environment.NewLine;

                //splits the input in to an array for translation
                string[] translateInput = inputText.Split(' ');

                //translates each word in the sentence
                for (int i = 0; i < translateInput.Length; i++)
                {
                    translation += translatePigLatin(translateInput[i]);
                }

                //prints the translated words to the output text box
                outputTextBox.Text += translation + Environment.NewLine;

                //Clearing the input box
                inputTextBox.Clear();
            }
            else //clears text box if invalid input
            {
                inputTextBox.Clear();
            }
        }

        private string translatePigLatin(string input)
        {
            //initializes needed variables for translation
            string word;
            //gathers the first letter in the input
            string firstLetter = input.Substring(0, 1);

            //translates the word
            word = input.Substring(1) + firstLetter + pigLatinEnding + " ";

            //returns the new translated word
            return word;
        }

        //validates the input as chars/spaces only
        bool validate(string value)
        {
            //checking each char
            foreach (char c in value)
            {
                //error box pop up if invalid input
                if (!char.IsLetter(c) && !char.IsWhiteSpace(c))
                {
                    string message = "Invalid Input, please enter only letters";
                    string title = "Error";
                    MessageBox.Show(message, title);
                    return false;
                }
            }
            return true;
        }
    }
}
