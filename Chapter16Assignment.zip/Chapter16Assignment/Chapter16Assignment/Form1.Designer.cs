﻿namespace Chapter16Assignment
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.inputTextBox = new System.Windows.Forms.TextBox();
            this.outputTextBox = new System.Windows.Forms.TextBox();
            this.translateButton = new System.Windows.Forms.Button();
            this.translatedSentences = new System.Windows.Forms.Label();
            this.originalSentences = new System.Windows.Forms.TextBox();
            this.originalInputs = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // inputTextBox
            // 
            this.inputTextBox.Location = new System.Drawing.Point(13, 13);
            this.inputTextBox.Name = "inputTextBox";
            this.inputTextBox.Size = new System.Drawing.Size(171, 20);
            this.inputTextBox.TabIndex = 0;
            // 
            // outputTextBox
            // 
            this.outputTextBox.Location = new System.Drawing.Point(13, 77);
            this.outputTextBox.Multiline = true;
            this.outputTextBox.Name = "outputTextBox";
            this.outputTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.outputTextBox.Size = new System.Drawing.Size(171, 77);
            this.outputTextBox.TabIndex = 1;
            // 
            // translateButton
            // 
            this.translateButton.Location = new System.Drawing.Point(203, 13);
            this.translateButton.Name = "translateButton";
            this.translateButton.Size = new System.Drawing.Size(75, 23);
            this.translateButton.TabIndex = 2;
            this.translateButton.Text = "Translate";
            this.translateButton.UseVisualStyleBackColor = true;
            this.translateButton.Click += new System.EventHandler(this.translateButton_Click);
            // 
            // translatedSentences
            // 
            this.translatedSentences.AutoSize = true;
            this.translatedSentences.Location = new System.Drawing.Point(51, 61);
            this.translatedSentences.Name = "translatedSentences";
            this.translatedSentences.Size = new System.Drawing.Size(89, 13);
            this.translatedSentences.TabIndex = 3;
            this.translatedSentences.Text = "Translated Inputs";
            // 
            // originalSentences
            // 
            this.originalSentences.Location = new System.Drawing.Point(203, 77);
            this.originalSentences.Multiline = true;
            this.originalSentences.Name = "originalSentences";
            this.originalSentences.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.originalSentences.Size = new System.Drawing.Size(171, 77);
            this.originalSentences.TabIndex = 4;
            // 
            // originalInputs
            // 
            this.originalInputs.AutoSize = true;
            this.originalInputs.Location = new System.Drawing.Point(251, 61);
            this.originalInputs.Name = "originalInputs";
            this.originalInputs.Size = new System.Drawing.Size(74, 13);
            this.originalInputs.TabIndex = 5;
            this.originalInputs.Text = "Original Inputs";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.originalInputs);
            this.Controls.Add(this.originalSentences);
            this.Controls.Add(this.translatedSentences);
            this.Controls.Add(this.translateButton);
            this.Controls.Add(this.outputTextBox);
            this.Controls.Add(this.inputTextBox);
            this.Name = "Form1";
            this.Text = "Pig Latin Translator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox inputTextBox;
        private System.Windows.Forms.TextBox outputTextBox;
        private System.Windows.Forms.Button translateButton;
        private System.Windows.Forms.Label translatedSentences;
        private System.Windows.Forms.TextBox originalSentences;
        private System.Windows.Forms.Label originalInputs;
    }
}

