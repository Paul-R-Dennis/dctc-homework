more_trips = True
x = 0

while more_trips:
    class Trip:
        def __init__(self,distance=0,gas_used=0):
            self.distance = distance
            self.gas_used = gas_used

        def calculateMpg(distance, gas_used):
            return distance/gas_used

        distance = input("How far did you go in miles? ")
        gas_used = input("How much gas did you use? ")
            
        mpg = calculateMpg(float(distance), float(gas_used))

        def add_trip(self,distance,gas_used):
            self.distance = distance
            self.gas_used = gas_used

        def __str__(self):
            return "Distance Traveled: " + str(Trip.distance) + "\nGas used: " + str(Trip.gas_used) + "\nMPG: " +str(self.mpg)

    moretrips = input("Would you like to enter another trip? (Y / N)")
    if moretrips == "N":
        more_trips = False
        

trip1 = Trip()
print(trip1)
