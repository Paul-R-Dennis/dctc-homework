﻿//Chapter 15 Assignment: Due 9/6/22
//Paul Dennis

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chapter15
{
    public partial class Parent : Form
    {
        // count number of child forms
        int count = 1;

        public Parent()
        {
            InitializeComponent();
        }

        //set text size
        public void textSize(float tSize)
        {
            Form form1 = this.ActiveMdiChild;
            RichTextBox rtb1 = (RichTextBox)form1.Controls["rtb"];
            rtb1.Font = new Font(rtb1.Font.FontFamily, tSize);
        }
        
        //set text Font
        public void textFont(string nFont)
        {
            Form form1 = this.ActiveMdiChild;
            RichTextBox rtb1 = (RichTextBox)form1.Controls["rtb"];
            rtb1.Font = new Font(nFont, rtb1.Font.Size);
        }


        private void Parent_Load(object sender, EventArgs e)
        {

        }

        //creates new child form
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Child child = new Child();
            child.MdiParent = this;
            child.Text += count.ToString();
            child.Show();
            count++;
        }


        //close a form
        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Form form1 = ActiveMdiChild;
                form1.Close();
                count--;
            }
            catch (NullReferenceException)
            {
                Application.Exit();
            }
        }

        //exit the application
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Application.Exit();
            }
            catch (NullReferenceException)
            {
                Application.Exit();
            }
        }

        //set text size to small
        private void smallToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                textSize(10);
            }
            catch (NullReferenceException)
            {
                Application.Exit();
            }
        }

        //set text size to medium
        private void mediumToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                textSize(20);
            }
            catch (NullReferenceException)
            {
                Application.Exit();
            }
        }

        //set text size to large
        private void largeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                textSize(30);
            }
            catch (NullReferenceException)
            {
                Application.Exit();
            }
        }

        //set text to Arial font
        private void arialToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                textFont("Arial");
            }
            catch (NullReferenceException)
            {
                Application.Exit();
            }
        }

        //set text to Times New Roman font
        private void timesNewRomanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                textFont("Times New Roman");
            }
            catch (NullReferenceException)
            {
                Application.Exit();
            }
        }

        //set text font to Calibri
        private void calibriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                textFont("Calibri");
            }
            catch (NullReferenceException)
            {
                Application.Exit();
            }
        }

        //change text color to Black
        private void blackToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Form form1 = this.ActiveMdiChild;
                RichTextBox data1 = (RichTextBox)form1.Controls["rtb"];
                data1.ForeColor = Color.Black;
            }
            catch (NullReferenceException)
            {
                Application.Exit();
            }
        }

        //change text color to Blue
        private void blueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Form form1 = this.ActiveMdiChild;
                RichTextBox data1 = (RichTextBox)form1.Controls["rtb"];
                data1.ForeColor = Color.Blue;
            }
            catch (NullReferenceException)
            {
                Application.Exit();
            }
        }

        //change text color to Red
        private void redToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Form form1 = this.ActiveMdiChild;
                RichTextBox data1 = (RichTextBox)form1.Controls["rtb"];
                data1.ForeColor = Color.Red;
            }
            catch (NullReferenceException)
            {
                Application.Exit();
            }
        }

        private void blueBackgroundToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Form form1 = this.ActiveMdiChild;
                RichTextBox data1 = (RichTextBox)form1.Controls["rtb"];
                data1.BackColor = Color.Blue;
            }
            catch (NullReferenceException)
            {
                Application.Exit();
            }

        }

        private void redBackgroundToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Form form1 = this.ActiveMdiChild;
                RichTextBox data1 = (RichTextBox)form1.Controls["rtb"];
                data1.BackColor = Color.Red;
            }
            catch (NullReferenceException)
            {
                Application.Exit();
            }
        }

        private void greenBackgroundToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Form form1 = this.ActiveMdiChild;
                RichTextBox data1 = (RichTextBox)form1.Controls["rtb"];
                data1.BackColor = Color.Green;
            }
            catch (NullReferenceException)
            {
                Application.Exit();
            }
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {

        }
    }
}
