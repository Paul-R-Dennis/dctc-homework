import java.util.Scanner;
import java.util.Arrays;
import java.util.HashMap;

public class ToDoApp {
	public static void main(String[] args) {
		//opens new scanner
		Scanner in = new Scanner(System.in);
		//creates new HashMap
		HashMap<String, ToDo> toDoList = new HashMap<>();

		
		//Initiates string value for do/while loop
		String end = "";
		do {
			//asks user what they would like to do
			System.out.println("What would you like to do? add item or lookup list");
			String choice = in.nextLine();
			//calls appropriate function based on user input
			switch(choice) {
				case "add item":
					add(in,toDoList);
					break;
				case "lookup list":
					lookup(in,toDoList);
					break;
				default:
					System.out.println("Invalid Entry");
					break;
			}
			
			//asks user if they would like to exit program
			System.out.println("Would you like to exit the program? (y/n)");
			end = in.nextLine();
		} while(!end.toLowerCase().equals("y"));
		in.close();
	}
	
	//Function for user to add an item to the list
	public static void add(Scanner in, HashMap<String,ToDo> toDoList) {
		//initiates string for do/while loop
		String addItem = "";
		do {
			//creates builder for adding items and gathers entered info
			ToDoBuilder toDoBuilder = new ToDoBuilder();
			System.out.println("What task would like to add to your To-Do list?");
			toDoBuilder.setName(in.nextLine());
			System.out.println("What is the description of this task?");
			toDoBuilder.setDescription(in.nextLine());
			System.out.println("Is this task complete?(y/n)");
			if (in.nextLine().toLowerCase() == "y") toDoBuilder.setDone();
			toDoList.put(toDoBuilder.getName(), toDoBuilder.build());
			
			//prompts user to ask if they would like another item added
			System.out.println("Would you like to add another item?(y/n)");
			addItem = in.nextLine();
		} while (!addItem.toLowerCase().equals("n"));
		
	}
	
	//Function for the user to lookup an item
	public static void lookup(Scanner in, HashMap<String,ToDo> toDoList) {
		String name;
		System.out.println("name of the task to lookup? (type all for all tasks)");
		name = in.nextLine();
		//prints entire ToDo List
		if (name == "all") {
			//Could not get entire list to print, searched online for different solutions with no luck.
			System.out.println(toDoList.keySet());
		}
		//prints single item from HashMap
		else {
			ToDo foundToDo = toDoList.get(name);
			System.out.println(foundToDo);
			System.out.println("Is the task complete? y/n");
			String complete = in.nextLine();
			if (complete.toLowerCase() == "y") {
				toDoList.put(name, toDoList.get(complete));
			}
		}
	}

}
