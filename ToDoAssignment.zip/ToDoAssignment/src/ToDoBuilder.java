public class ToDoBuilder {
	private String name;
	private String description;
	private boolean done;
	
	//Created Setters and Getters for all fields
	public ToDoBuilder setName(String name) {
		this.name = name;
		return this;
	}
	public ToDoBuilder setDescription(String description) {
		this.description = description;
		return this;
	}
	public ToDoBuilder setDone() {
		this.done = true;
		return this;
	}
	
	public String getName() {
		return name;
	}
	public String getDescription() {
		return description;
	}
	public boolean isDone() {
		return done;
	}
	
	//Builds the object
	public ToDo build() {
		return new ToDo(name, description, done);
	}
}
