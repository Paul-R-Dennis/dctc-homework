﻿// Ex. 17.8: StudentPoll.cs
// Allow student to take a survey
// and view the results in a TextBox
using System;
using System.Windows.Forms;
using System.IO;

namespace StudentPoll
{
   public partial class StudentPollForm : Form
   {
      StreamWriter writer;
      StreamReader input;
      int number;
      private const string filePath = "numbers.txt";
 

      // parameterless constructor
      public StudentPollForm()
      {
         InitializeComponent();

         //Create the StreamWriter object
         using (StreamWriter writer = new StreamWriter("numbers.txt"))
            {
                
            }

      } // end constructor

      private void inputTextBox_KeyDown(object sender, KeyEventArgs e)
      {
         if (e.KeyCode == Keys.Enter)
         {
                try
                {

                    //Add exception handling


                    if (String.IsNullOrEmpty(inputTextBox.Text))
                    {
                        MessageBox.Show("Please fill in the TextBox.");
                    } // end if
                    else
                    {

                        number = Convert.ToInt32(inputTextBox.Text);

                        //  Validate that the number is 1 - 10. When valid, use method Write to put the value into the file
                        if (number >= 1 || number <= 10)
                        {
                            
                        }
                        else
                        {
                            MessageBox.Show("Please enter a number 1-10");
                            inputTextBox.Clear();
                        }
                        //checked number then wrote to writer.

                    } // end else

                    inputTextBox.Clear();
                } catch (IOException)
                {
                    MessageBox.Show("Invalid Input");
                }
         } // end if
      }

      private void doneButton_Click(object sender, EventArgs e)
      {
         writer.Close();
            //TODO *********************************
            //Change properties such that the display button can be used and this button can't be used. The textbox should be read-only
            //changed to quit button
            Application.Exit();
        }

      private void displayButton_Click(object sender, EventArgs e)
      {
         input = new StreamReader(filePath);
         

         string inputString = input.ReadToEnd();
         string[] stringArray = inputString.Split(' ');
         int[] frequency = new int[11];

         //TODO ******************
         //Split the read data into the array. Populate another integer array with the values from the string array converted
         //   to integers. Update the frequency array to include a count for each of the responses. Refer to Figure 8.8
         
        

         displayTextBox.Clear();
         displayTextBox.AppendText("Rating\tFrequency\n");

         //TODO *******************
         //Write out the ratings and frequencies
         for (int i = 0; i < stringArray.Length; i++)
            {
                displayTextBox.Text += ($"{0}\t{1}\n", i + 1, frequency[i]);
            }

       
      } // end method displayButton_Click

        private void StudentPollForm_Load(object sender, EventArgs e)
        {
        }

        private void inputTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void recordAnswer_Click(object sender, EventArgs e)
        {

        }
    } // end class StudentPollForm
} // end namespace StudentPoll

